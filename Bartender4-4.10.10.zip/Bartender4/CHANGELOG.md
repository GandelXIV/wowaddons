# Bartender4

## [4.10.10](https://github.com/Nevcairiel/Bartender4/tree/4.10.10) (2021-06-29)
[Full Changelog](https://github.com/Nevcairiel/Bartender4/compare/4.10.9...4.10.10) [Previous Releases](https://github.com/Nevcairiel/Bartender4/releases)

- Update retail TOC to 9.1  
- Add the ability for a bar to grow horizontally in both directions (the bar stays centered)  
- Support Tree of Life stance bar swapping  
    It does not have a bar assigned to it by default, since it being a  
    separate caster form which shares many of the same spells as the  
    original, bar swapping is of limited use only.  
    A bar to swap to can be assigned in the configuration.  
