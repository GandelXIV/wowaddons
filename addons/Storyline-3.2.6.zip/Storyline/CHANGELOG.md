## Changelog for version 3.2.6

### Fixed

- Fixed the issue preventing from picking a reputation reward from the Oribos weekly dungeon quests. (Big thanks to Solanya for his help on this one).
- Improved the scaling of more Shadowlands NPC models.
- The Shadowlands zone specific backgrounds now uses nicer textures from the convenant choice UI.