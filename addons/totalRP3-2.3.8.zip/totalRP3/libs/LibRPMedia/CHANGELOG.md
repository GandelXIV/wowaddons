## v1.1.8
### Changed
- Updated for Retail patch 9.1.0 with 323 new icons and 138 new music files.
