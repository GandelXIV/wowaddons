# GSE: Advanced Macro Compiler

## [3.0.52](https://github.com/TimothyLuke/GSE-Advanced-Macro-Compiler/tree/3.0.52) (2021-11-02)
[Full Changelog](https://github.com/TimothyLuke/GSE-Advanced-Macro-Compiler/compare/3.0.50...3.0.52) [Previous Releases](https://github.com/TimothyLuke/GSE-Advanced-Macro-Compiler/releases)

- #1067 9.1.5 TOC changes  
