# Addon Control Panel

## [3.5.7](https://github.com/sylvanaar/addon-control-panel/tree/3.5.7) (2020-01-19)
[Full Changelog](https://github.com/sylvanaar/addon-control-panel/compare/3.5.6...3.5.7)

- Update TOC for retail and classic  
- Update README.md  
- Update README.md  