SimulationCraft Addon
=====================

This addon collects information about your character and presents a text version suitable for running in Simc

Usage
=====

Type `/simc` in-game to display text input that you can copy/paste to SimulationCraft.

`/simc nobags` will only output character on your gear, not items in your bags.

`/simc minimap` will toggle the minimap icon.

`/simc [Item Link]` can be used to add additional items to the output. For example, type `/simc`, add a space, then
shift left-click an item (from chat, a recent boss drop, or an item from a vendor) and that item will be added as a
comment below bag items in the text. WoW chat does have a character limit so the output may only contain the first 2-3
items that you link.

Maintainers
-----------

* navv
* seriallos
* aethys
* Theck (retired)
