local L = LibStub('AceLocale-3.0'):NewLocale('Scrap', 'esES') or LibStub('AceLocale-3.0'):NewLocale('Scrap', 'esMX')
if not L then return end

L.Add = 'Añadir a la Lista de Basura'
L.Added = 'Añadido a la Lista de Basura: %s'
L.AutoSell = 'Auto Vender'
L.AutoSellTip = 'Si está habilitado, Scrap venderá automáticamente toda tu basura cuando visites a un mercader.'
L.Junk = 'Basura'
L.Remove = 'Eliminar de la Lista de Basura'
L.Removed = 'Eliminado de la Lista de Basura: %s'
L.SellJunk = 'Vender Basura'
L.SoldJunk = 'Has vendido tu basura por %s'
L.Repaired = 'Has reparado tu equipamento por %s'
