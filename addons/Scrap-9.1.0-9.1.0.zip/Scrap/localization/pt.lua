local L = LibStub('AceLocale-3.0'):NewLocale('Scrap', 'ptBR')
if not L then return end

L.Add = 'Definir como Lixo'
L.Added = 'Definido como lixo: %s'
L.AdvancedOptions = 'Opções Avançadas'
L.AutoSell = 'Vender Automaticamente'
L.AutoSellTip = 'Se activado, Scrap venderá automaticamente todo o seu lixo quando visitar um comerciante.'
L.Junk = 'Lixo'
L.Loading = 'Carregando...'
L.NotJunk = 'Útil'
L.Description = 'Estas opções permitem-lhe levar a sua configuração a outro nível. The trash shall not pass!'
L.Remove = 'Definir como Útil'
L.Removed = 'Definido como útil: %s'
L.SafeMode = 'Modo Seguro'
L.SellJunk = 'Vender Lixo'
L.SoldJunk = 'Vendeu seu lixo por %s'
L.Repaired = 'Reparou seu equipamento por %s'
