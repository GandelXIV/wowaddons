--[[
Copyright 2008-2021 João Cardoso
Scrap is distributed under the terms of the GNU General Public License (Version 3).
As a special exception, the copyright holders of this addon do not give permission to
redistribute and/or modify it.

This addon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the addon. If not, see <http://www.gnu.org/licenses/gpl-3.0.txt>.

This file is part of Scrap.
--]]

Scrap.baseList = {__index = {
	[90561] = false,
	[12709] = false,
	[2459] = false,
	[29532] = false,
	[29530] = false,
	[39878] = false,
	[40586] = false,
	[48954] = false,
	[48955] = false,
	[48956] = false,
	[48957] = false,
	[45688] = false,
	[45689] = false,
	[45690] = false,
	[45691] = false,
	[44934] = false,
	[44935] = false,
	[51560] = false,
	[51558] = false,
	[51559] = false,
	[51557] = false,
	[40585] = false,
	[43157] = false,
	[63206] = false,
	[63207] = false,
	[65274] = false,
	[63353] = false,
	[64402] = false,
	[64401] = false,
	[64400] = false,
	[63352] = false,
	[86143] = false,
	[92742] = false,
	[92741] = false,
	[92665] = false,
	[92675] = false,
	[92676] = false,
	[92677] = false,
	[92678] = false,
	[92679] = false,
	[92680] = false,
	[92681] = false,
	[92682] = false,
	[92683] = false,
	[33820] = false,
	[19969] = false,
	[89124] = false,
	[114131] = false,
	[114808] = false,
	[114129] = false,
	[114745] = false,
	[114128] = false,
	[120301] = false,
	[120302] = false,
	[114002] = false,
	[156631] = false,
	[24368] = false,
	[40772] = false,
	[114943] = false,
	[109253] = false,
}}
