local L

-----------------------
-- Valinor, the Light of Eons --
-----------------------
--L= DBM:GetModLocalization(2430)

-----------------------
-- Mortanis --
-----------------------
--L= DBM:GetModLocalization(2431)

-----------------------
-- Oranomonos the Everbranching --
-----------------------
--L= DBM:GetModLocalization(2432)

-----------------------
-- Nurgash Muckformed --
-----------------------
--L= DBM:GetModLocalization(2433)

-----------------------
-- Mor'geth, Tormentor of the Damned --
-----------------------
L= DBM:GetModLocalization(2456)

L:SetMiscLocalization({
	Pull	= "Your souls are mine to claim!"
})
