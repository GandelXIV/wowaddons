# Clique

## [v3.1.2](https://github.com/jnwhiteh/Clique/tree/v3.1.2) (2021-11-04)
[Full Changelog](https://github.com/jnwhiteh/Clique/compare/v3.1.1...v3.1.2) [Previous Releases](https://github.com/jnwhiteh/Clique/releases)

- Merge pull request #3 from jnwhiteh/jnwhiteh-9.1.5-update-toc  
    Update TOC for 9.1.5  
- Update TOC for 9.1.5  