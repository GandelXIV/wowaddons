# OmniCC :clock1:

OmniCC is an World of Wacraft addon that adds text to items, spell and abilities that are on cooldown to indicate when they will be ready to use. In other words: it turns all the standard analogue cooldowns into digital ones.

Anything should work with OmniCC, from the action bars to the inventory, from the standard interface to your favorite add-on.

![Preview](http://jaliborc.com/images/addons/large/omnicc/actions.jpg)

[![Patreon](http://jaliborc.com/images/external/patreon.png#1)](https://www.patreon.com/jaliborc)
