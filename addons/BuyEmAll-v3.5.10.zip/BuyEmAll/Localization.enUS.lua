

if GetLocale() == "enUS" then
	BUYEMALL_LOCALS = {
	MAX 			= "Max",
	STACK 			= "Stack",
	CONFIRM 		= "Are you sure you want to buy\n %d × %s?",
	STACK_PURCH		= "Stack Purchase",
	STACK_SIZE 		= "Stack size",
	PARTIAL 		= "Partial stack",
	MAX_PURCH		= "Maximum purchase",
	FIT				= "You can fit",
	AFFORD			= "You can afford",
	AVAILABLE		= "Vendor has",
}
end

local L = BUYEMALL_LOCALS;
