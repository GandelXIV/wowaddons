-- Thanks to OUGHT!

if GetLocale() == "ruRU" then
	BUYEMALL_LOCALS = {
	MAX 			= "Макс.",
	STACK 			= "Стопка",
	CONFIRM 		= "Вы уверены, что хотите купить\n %d х %s?",
	STACK_PURCH		= "Покупка стопки",
	STACK_SIZE 		= "Размер стопки",
	PARTIAL 		= "Неполная стопка",
	MAX_PURCH		= "Максимум покупки",
	FIT				= "Вы можете взять",
	AFFORD			= "Вы можете себе позволить",
	AVAILABLE		= "Продавец имеет",
}
end

local L = BUYEMALL_LOCALS;
