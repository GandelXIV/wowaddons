# NugComboBar

## [9.1.0](https://github.com/rgd87/NugComboBar/tree/9.1.0) (2021-07-16)
[Full Changelog](https://github.com/rgd87/NugComboBar/compare/9.0.9...9.1.0) [Previous Releases](https://github.com/rgd87/NugComboBar/releases)

- Updated TOC  
- Fixed Echoing Remprimand for the new legendary  
- Fixed CPs not updating after switching target  
- Fixed visiblity bugs with various settings when attached to nameplate  
- Show on neutral mobs when attached to nameplate  
- Fixed default rogue config name  
- Classic toc  
- Added split tocs for BCC and 9.1  
- Split classic and mainline configs  
- Classic compatible 3D presets  
- Merged classic support into mainline  
- Ignore friendly nameplates  
