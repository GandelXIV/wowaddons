function Auctionator.Utilities.CreateMoneyString(count)
  return Auctionator.Utilities.DelimitThousands(GetCoinTextureString(count))
end
