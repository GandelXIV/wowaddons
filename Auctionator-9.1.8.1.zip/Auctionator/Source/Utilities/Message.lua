function Auctionator.Utilities.Message(message)
  print(
    LIGHTBLUE_FONT_COLOR:WrapTextInColorCode("Auctionator: ")
    .. message
  )
end
