Auctionator.Constants.DialogNames = {
  CreateShoppingList = "AUCTIONATOR_CREATE_SHOPPING_LIST",
  DeleteShoppingList = "AUCTIONATOR_DELETE_SHOPPING_LIST",
  AddItemToShoppingList = "AUCTIONATOR_ADD_ITEM_TO_SHOPPING_LIST",
  RenameShoppingList = "AUCTIONATOR_RENAME_SHOPPING_LIST"
}