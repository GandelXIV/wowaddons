Auctionator.Constants.ITEM_INFO = {
  NAME = 1,
  LINK = 2,
  RARITY = 3,
  TEXTURE = 10,
  SELL_PRICE = 11,
  CLASS = 12,
  BIND_TYPE = 14,
  XPAC = 15,
  REAGENT = 17,
}
