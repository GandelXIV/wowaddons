Auctionator.Selling.Events = {
  BagItemClicked = "bag_item_clicked",
  BagRefresh = "bag_refresh",
  RequestPost = "selling_request_post",
  AuctionCreated = "selling_auction_created",
  ItemIconCallback = "selling_item_icon_callback",
}
