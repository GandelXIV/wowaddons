Auctionator.IncrementalScan.Events = {
  ScanStart = "full_incremental_scan_start",
  ScanProgress = "full_incremental_scan_progress",
  ScanComplete = "full_incremental_scan_complete",
  ScanFailed = "full_incremental_scan_failed",
  PricesProcessed = "incremental_prices_processed",
}
