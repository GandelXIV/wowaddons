Auctionator.Config.InitializeFrames({
  "BasicOptions",
  "Tooltips",

  "Shopping",
  "Selling",
  "SellingShortcuts",
  "LIFO",
  "NotLIFO",
  "Quantities",
  "Cancelling",

  "Profile",

  "Advanced",
})
