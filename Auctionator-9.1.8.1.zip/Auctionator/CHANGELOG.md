# Auctionator

## [9.1.8.1](https://github.com/Auctionator/Auctionator/tree/9.1.8.1) (2021-10-26)
[Full Changelog](https://github.com/Auctionator/Auctionator/compare/9.1.8...9.1.8.1) [Previous Releases](https://github.com/Auctionator/Auctionator/releases)

- TBC: Fix error when clicking on a favourite in the Selling tab  
- [Fixes #1076] Disable buy button when not enough gold to buy the stack  
- [Fixes #1074] Make "Cancel Undercut" button work on Cancelling tab  
- Use newer Enum.ItemClass instead of the LE_ constants  
- Update issue templates  