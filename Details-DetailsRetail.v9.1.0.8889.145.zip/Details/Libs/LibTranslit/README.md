# LibTranslit

Transliterate string

## Usage

```Lua
local LibTranslit = LibStub("LibTranslit-1.0")
local transliteratedString = LibTranslit:Transliterate(string[, mark])
```