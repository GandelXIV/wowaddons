# [3.7.2](https://github.com/WeakAuras/WeakAuras2/tree/3.7.2) (2021-10-02)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/3.7.1...3.7.2)

## Highlights

 - New sounds and textures (thanks Leo!)
- TOC update for Classic Era
- Bug fixes 

## Commits

InfusOnWoW (1):

- Add Textures and Sounds by Leo

Stanzilla (9):

- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools
- Update WeakAurasModelPaths from wow.tools

mrbuds (6):

- update toc files for classic era 1.14.0
- fix castbar latency overlay nil error fixes #3314
- character stats trigger: add block value fixes  #3303
- rework cast trigger latency overlay fixes #3294
- fix error when hovering ZoneID fixes  #3306
- Enable TTS actions for TBC, fixes #3288

