# Grid2

## [2.0.25](https://github.com/michaelnpsp/Grid2/tree/2.0.25) (2021-09-30)
[Full Changelog](https://github.com/michaelnpsp/Grid2/compare/2.0.24...2.0.25) 

- TOC Update for Classic Era (vanilla).  
- Updated LibHealComm library.  
- TBC: Updated Zulaman, Black Temple and Sunwell Plateu Raid Debuffs.  
